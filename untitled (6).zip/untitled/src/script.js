document.querySelector('button').addEventListener('click', () => {
  alert('Message sent!');
});